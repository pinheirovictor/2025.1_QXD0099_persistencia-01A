#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <array>
#include <set>
#include <vector>

class Modification;
class LineSegment;
class Point;
class TreeNode;
class RedBlackTreePersistent;
class LeftChildModification;
class LeftChildModification;
class LineSegment;
class FloatInterval;

class FloatInterval {
    public:
        float begin = 0.0f;
        float end = 0.0f;
};

class Point {
    public:
        float x, y;
        LineSegment* owner_line;

        Point (float x, float y){
            this->x = x;
            this->y = y;
        }

};

class LineSegment {

    private:
        int id;
        Point* pointA;
        Point* pointB;
        float linearCoeficient;
        float angularCoeficient;

    public:
        LineSegment(int id) : id(id), pointA(nullptr), pointB(nullptr), linearCoeficient(0.0f), angularCoeficient(0.0f) {}

        LineSegment(int id, Point* pointA, Point* pointB) : id(id), pointA(pointA), pointB(pointB) {
            calculateCoefficients();
        }

        LineSegment(int x1, int y1, int x2, int y2) {
            pointA = new Point(x1, y1);
            pointB = new Point(x2, y2);
            calculateCoefficients();
        }

        ~LineSegment() {
            delete pointA;
            delete pointB;
        }

        float getYValueByLineEquation(float x) const {
            return angularCoeficient * x + linearCoeficient;
        }

        int getId() const {
            return id;
        }

        Point* getPointA() const {
            return pointA;
        }

        Point* getPointB() const {
            return pointB;
        }

        float getLinearCoeficient() const {
            return linearCoeficient;
        }

        float getAngularCoeficient() const {
            return angularCoeficient;
        }

    private:
        void calculateCoefficients() {
            if (pointA && pointB) {
                angularCoeficient = float(pointB->y - pointA->y) / float(pointB->x - pointA->x);
                linearCoeficient = pointA->y - angularCoeficient * pointA->x;
            }
        }
};

class Modification {

    public:
        enum class Type { Left, Right, Color };

    private:
        Type type;
        char newColor;
        TreeNode* newNode;
        int version;

    public:
        Modification(Type type, char newColor, int version)
            : type(type), newColor(newColor), newNode(nullptr), version(version) {}

        Modification(Type type, TreeNode* newNode, int version)
            : type(type), newColor('\0'), newNode(newNode), version(version) {}

        Type getType() const {
            return type;
        }

        char getNewColor() const {
            return newColor;
        }

        TreeNode* getNewNode() const {
            return newNode;
        }

        int getVersion() const {
            return version;
        }
};

class TreeNode {

    private:
        int getNumberOfMods() const {
            int count = 0;
            if (modifications[0] != nullptr) count++;
            if (modifications[1] != nullptr) count++;
            return count;
        }

        TreeNode* duplicateNodeWithMods() {
            TreeNode* resultNode = new TreeNode();
            resultNode->line = this->line;
            resultNode->left = this->left;
            resultNode->right = this->right;
            resultNode->color = this->color;
            for (size_t i = 0; i < getNumberOfMods(); i++) {
                switch (this->modifications[i]->getType()) {
                    case Modification::Type::Left:
                        resultNode->left = modifications[i]->getNewNode();
                        break;
                    case Modification::Type::Right:
                        resultNode->right = modifications[i]->getNewNode();
                        break;
                    case Modification::Type::Color:
                        resultNode->color = modifications[i]->getNewColor();
                        break;
                }
            }
            return resultNode;
        }

    public:
        LineSegment* line;
        char color = 'R';
        TreeNode* left = nullptr;
        TreeNode* right = nullptr;
        Modification* modifications[2] = {nullptr, nullptr};

        TreeNode() {}
        TreeNode(LineSegment* line) : line(line) {}

        TreeNode* addMod(Modification* newMod) {
            if (this->getNumberOfMods() < 2) {
                if (modifications[0] == nullptr)
                    modifications[0] = newMod;
                else if (modifications[1] == nullptr)
                    modifications[1] = newMod;
                return this;
            } else {
                TreeNode* resultNode = duplicateNodeWithMods();
                resultNode->modifications[0] = newMod;
                return resultNode;
            }
        }

        TreeNode* getLeftChildByVersion(int version) const {
            TreeNode* leftChildNode = this->left;
            if (modifications[0] && modifications[0]->getType() == Modification::Type::Left && modifications[0]->getVersion() <= version) {
                leftChildNode = modifications[0]->getNewNode();
            }
            if (modifications[1] && modifications[1]->getType() == Modification::Type::Left && modifications[1]->getVersion() <= version) {
                leftChildNode = modifications[1]->getNewNode();
            }
            return leftChildNode;
        }

        TreeNode* setLeftChildNodeByVersion(int version, TreeNode* node) {
            return this->addMod(new Modification(Modification::Type::Left, node, version));
        }

        TreeNode* setRightChildNodeByVersion(int version, TreeNode* node) {
            return this->addMod(new Modification(Modification::Type::Right, node, version));
        }

        TreeNode* setNewLeftChildNodeByVersion(int version, LineSegment* line) {
            return this->addMod(new Modification(Modification::Type::Left, new TreeNode(line), version));
        }

        TreeNode* setNewRightChildNodeByVersion(int version, LineSegment* line) {
            return this->addMod(new Modification(Modification::Type::Right, new TreeNode(line), version));
        }

        TreeNode* getRightChildByVersion(int version) const {
            TreeNode* rightChildNode = this->right;
            if (modifications[0] && modifications[0]->getType() == Modification::Type::Right && modifications[0]->getVersion() <= version) {
                rightChildNode = modifications[0]->getNewNode();
            }
            if (modifications[1] && modifications[1]->getType() == Modification::Type::Right && modifications[1]->getVersion() <= version) {
                rightChildNode = modifications[1]->getNewNode();
            }
            return rightChildNode;
        }

        char getColorByVersion(int version) const {
            char result = this->color;
            if (modifications[0] && modifications[0]->getType() == Modification::Type::Color && modifications[0]->getVersion() <= version) {
                result = modifications[0]->getNewColor();
            }
            if (modifications[1] && modifications[1]->getType() == Modification::Type::Color && modifications[1]->getVersion() <= version) {
                result = modifications[1]->getNewColor();
            }
            return result;
        }

        TreeNode* setColorByVersion(char newColor, int version) {
            return this->addMod(new Modification(Modification::Type::Color, newColor, version));
        }
};

class RedBlackTreePersistent {
    private:
        int getCurrentVersionNumber() const { 
            return static_cast<int>(this->rootHistory.size()); 
        }

        TreeNode* getNodeByLineOnCurrentVersion(LineSegment *line) const {
            TreeNode* currentNode = this->rootHistory.back();

            while (currentNode->line != line) {
                if (currentNode->line->getPointA()->y > line->getPointA()->y) {
                    currentNode = currentNode->getLeftChildByVersion(this->getCurrentVersionNumber());
                } else {
                    currentNode = currentNode->getRightChildByVersion(this->getCurrentVersionNumber());
                }
            }

            return currentNode;
        }

        TreeNode* rotateLeft(TreeNode* root, int version) {
            TreeNode* x = root;
            TreeNode* y = x->getRightChildByVersion(version);
            TreeNode* T2 = y->getLeftChildByVersion(version);

            x = x->setRightChildNodeByVersion(version, T2);
            y = y->setLeftChildNodeByVersion(version, x);
            
            y = y->setColorByVersion(x->getColorByVersion(version), version);
            x = x->setColorByVersion('R', version);

            if (y->getLeftChildByVersion(version) != x) {
                y = y->setLeftChildNodeByVersion(version, x);
            }

            return y;
        }

        TreeNode* rotateRight(TreeNode* root, int version) {
            TreeNode* y = root;
            TreeNode* x = y->getLeftChildByVersion(version);
            TreeNode* T2 = x->getRightChildByVersion(version);

            y = y->setLeftChildNodeByVersion(version, T2);
            x = x->setRightChildNodeByVersion(version, y);

            x = x->setColorByVersion(y->getColorByVersion(version), version);
            y = y->setColorByVersion('R', version);

            if (x->getRightChildByVersion(version) != y) {
                x = x->setRightChildNodeByVersion(version, y);
            }

            return x;
        }

        TreeNode* invertNodeColor(TreeNode* node) {
            int version = this->getCurrentVersionNumber();
            if (!node) return nullptr;
            if (node->getColorByVersion(version) == 'B') {
                return node->setColorByVersion('R', version);
            } else {
                return node->setColorByVersion('B', version);
            }
        }

        char getNodeColorOnCurrentVersion(TreeNode* node, int version) const {
            if (!node) return 'B';
            return node->getColorByVersion(version);
        }

    public:
        TreeNode* root = nullptr;
        std::vector<TreeNode*> rootHistory = {nullptr};

        RedBlackTreePersistent() {}

        TreeNode* getNodeLeftChildOnLastVersion(TreeNode* node) const {
            return node->getLeftChildByVersion(this->getCurrentVersionNumber());
        }

        TreeNode* getNodeRightChildOnLastVersion(TreeNode* node) const {
            return node->getRightChildByVersion(this->getCurrentVersionNumber());
        }

        TreeNode* findNodeByLineAndVersion(LineSegment* line, int version) {
            TreeNode* root = this->rootHistory[version];

            while (line != root->line) {
                if (line->getPointA()->y < root->line->getPointA()->y) {
                    root = root->getLeftChildByVersion(version);
                } else if (line->getPointA()->y > root->line->getPointA()->y) {
                    root = root->getRightChildByVersion(version);
                } else {
                    if (line->getAngularCoeficient() < root->line->getAngularCoeficient()) {
                        root = root->getLeftChildByVersion(version);
                    } else if (line->getAngularCoeficient() > root->line->getAngularCoeficient()) {
                        root = root->getRightChildByVersion(version);
                    }
                }
            }

            return root;
        }

        TreeNode* findStrictSuccessor(TreeNode* node, int version);

        TreeNode* getSuccessor(TreeNode* node, int version) {
            TreeNode* currentNode = node;
            TreeNode* leftChildNode = node->getLeftChildByVersion(this->getCurrentVersionNumber());

            while (leftChildNode) {
                currentNode = leftChildNode;
                leftChildNode = currentNode->getLeftChildByVersion(this->getCurrentVersionNumber());
            }

            return currentNode;
        }

        TreeNode* push(LineSegment* line, TreeNode* root) { 
            TreeNode* firstRoot = root;
            int version = this->getCurrentVersionNumber();

            if (!this->root) {
                TreeNode* newNode = new TreeNode(line);
                this->root = newNode;
                this->rootHistory.push_back(newNode);
                this->root->color = 'B';
                return this->root;
            }

            if (line->getPointA()->y < root->line->getPointA()->y) {
                if (!this->getNodeLeftChildOnLastVersion(root)) {
                    root = root->setNewLeftChildNodeByVersion(version, line);
                } else {
                    TreeNode* pushResult = this->push(line, root->getLeftChildByVersion(version));
                    if (pushResult != root->getLeftChildByVersion(version)) {
                        root = root->setLeftChildNodeByVersion(version, pushResult);
                    }
                }
            } else if (line->getPointA()->y > root->line->getPointA()->y) {
                if (!this->getNodeRightChildOnLastVersion(root)) {
                    root = root->setNewRightChildNodeByVersion(version, line);
                } else {
                    TreeNode* pushResult = this->push(line, root->getRightChildByVersion(version));
                    if (pushResult != root->getRightChildByVersion(version)) {
                        root = root->setRightChildNodeByVersion(version, pushResult);
                    }
                }
            } else {
                if (line->getAngularCoeficient() < root->line->getAngularCoeficient()) {
                    if (!this->getNodeLeftChildOnLastVersion(root)) {
                        root = root->setNewLeftChildNodeByVersion(version, line);
                    } else {
                        TreeNode* pushResult = this->push(line, root->getLeftChildByVersion(version));
                        if (pushResult != root->getLeftChildByVersion(version)) {
                            root = root->setLeftChildNodeByVersion(version, pushResult);
                        }
                    }
                } else if (line->getAngularCoeficient() > root->line->getAngularCoeficient()) {
                    if (!this->getNodeRightChildOnLastVersion(root)) {
                        root = root->setNewRightChildNodeByVersion(version, line);
                    } else {
                        TreeNode* pushResult = this->push(line, root->getRightChildByVersion(version));
                        if (pushResult != root->getRightChildByVersion(version)) {
                            root = root->setRightChildNodeByVersion(version, pushResult);
                        }
                    }
                } else {
                    float mediumPointX = (root->line->getPointA()->x + line->getPointB()->x) / 2;
                    float mediumPointOverLine = line->getYValueByLineEquation(mediumPointX);
                    float mediumPointOverRootLine = root->line->getYValueByLineEquation(mediumPointX);
                    if (mediumPointOverLine < mediumPointOverRootLine) {
                        if (!this->getNodeLeftChildOnLastVersion(root)) {
                            root = root->setNewLeftChildNodeByVersion(version, line);
                        } else {
                            TreeNode* pushResult = this->push(line, root->getLeftChildByVersion(version));
                            if (pushResult != root->getLeftChildByVersion(version)) {
                                root = root->setLeftChildNodeByVersion(version, pushResult);
                            }
                        }
                    } else if (mediumPointOverLine > mediumPointOverRootLine) {
                        if (!this->getNodeRightChildOnLastVersion(root)) {
                            root = root->setNewRightChildNodeByVersion(version, line);
                        } else {
                            TreeNode* pushResult = this->push(line, root->getRightChildByVersion(version));
                            if (pushResult != root->getRightChildByVersion(version)) {
                                root = root->setRightChildNodeByVersion(version, pushResult);
                            }
                        }
                    }
                }
            }

            // Fix Violations
            char leftColor = this->getNodeColorOnCurrentVersion(root->getLeftChildByVersion(version), version);
            char rightColor = this->getNodeColorOnCurrentVersion(root->getRightChildByVersion(version), version);
            char leftLeftColor = (this->getNodeLeftChildOnLastVersion(root) != nullptr) 
                ? this->getNodeColorOnCurrentVersion(getNodeLeftChildOnLastVersion(root->getLeftChildByVersion(version)), version) 
                : ' ';

            if (rightColor == 'R' && leftColor == 'B') {
                root = rotateLeft(root, version);
            }

            leftColor = this->getNodeColorOnCurrentVersion(root->getLeftChildByVersion(version), version);
            rightColor = this->getNodeColorOnCurrentVersion(root->getRightChildByVersion(version), version);
            leftLeftColor = (this->getNodeLeftChildOnLastVersion(root) != nullptr) 
                ? this->getNodeColorOnCurrentVersion(getNodeLeftChildOnLastVersion(root->getLeftChildByVersion(version)), version) 
                : ' ';

            if (leftColor == 'R' && leftLeftColor == 'R') {
                root = rotateRight(root, version);
            }

            leftColor = this->getNodeColorOnCurrentVersion(root->getLeftChildByVersion(version), version);
            rightColor = this->getNodeColorOnCurrentVersion(root->getRightChildByVersion(version), version);
            leftLeftColor = (this->getNodeLeftChildOnLastVersion(root) != nullptr) 
                ? this->getNodeColorOnCurrentVersion(getNodeLeftChildOnLastVersion(root->getLeftChildByVersion(version)), version) 
                : ' ';

            if (leftColor == 'R' && rightColor == 'R') {
                root = invertNodeColor(root);
                TreeNode* rootLeftAfterColorChange = invertNodeColor(root->getLeftChildByVersion(version));
                if (rootLeftAfterColorChange != root->getLeftChildByVersion(version)) {
                    root = root->setLeftChildNodeByVersion(version, rootLeftAfterColorChange);
                }
                TreeNode* rootRightAfterColorChange = invertNodeColor(root->getRightChildByVersion(version));
                if (rootRightAfterColorChange != root->getRightChildByVersion(version)) {
                    root = root->setRightChildNodeByVersion(version, rootRightAfterColorChange);
                }
            }

            // Handle Root
            if (this->root->line == firstRoot->line) {
                this->root = root;
                if (this->root->getColorByVersion(version) == 'R') {
                    this->root = this->root->setColorByVersion('B', version);
                }
                this->rootHistory.push_back(this->root);
            }

            return root;
        }

        TreeNode* remove(LineSegment* line, TreeNode* root) {
            TreeNode* firstRoot = root;
            int version = this->getCurrentVersionNumber();

            if (!root) return nullptr;
            
            if (line->getPointA()->y < root->line->getPointA()->y) {
                TreeNode* result = this->remove(line, root->getLeftChildByVersion(version));
                if (result != root->getLeftChildByVersion(version)) {
                    root = root->setLeftChildNodeByVersion(version, result);
                }
            } else if (line->getPointA()->y > root->line->getPointA()->y) {
                TreeNode* result = this->remove(line, root->getRightChildByVersion(version));
                if (result != root->getRightChildByVersion(version)) {
                    root = root->setRightChildNodeByVersion(version, result);
                }
            } else {
                if (line->getAngularCoeficient() < root->line->getAngularCoeficient()) {
                    TreeNode* result = this->remove(line, root->getLeftChildByVersion(version));
                    if (result != root->getLeftChildByVersion(version)) {
                        root = root->setLeftChildNodeByVersion(version, result);
                    }
                } else if (line->getAngularCoeficient() > root->line->getAngularCoeficient()) {
                    TreeNode* result = this->remove(line, root->getRightChildByVersion(version));
                    if (result != root->getRightChildByVersion(version)) {
                        root = root->setRightChildNodeByVersion(version, result);
                    }
                } else {
                    // TODO: Handle overlapping lines with the same y and angular coefficient
                }

                if (root->line == line) {
                    if (!root->getLeftChildByVersion(version) && !root->getRightChildByVersion(version)) {
                        if (root == this->root) {
                            this->root = nullptr;
                            this->rootHistory.push_back(nullptr);
                        }
                        return nullptr;
                    }

                    if (!root->getLeftChildByVersion(version) || !root->getRightChildByVersion(version)) {
                        TreeNode* child = root->getLeftChildByVersion(version) ? root->getLeftChildByVersion(version) : root->getRightChildByVersion(version);

                        if (root == this->root) {
                            this->root = child;
                            if (this->root->getColorByVersion(version) == 'R') {
                                this->root->setColorByVersion('B', version);
                            }
                            this->rootHistory.push_back(this->root);
                        }
                        return child;
                    }

                    if (root->getLeftChildByVersion(version) && root->getRightChildByVersion(version)) {
                        TreeNode* successor = this->getSuccessor(root, version);
                        if (root == this->root) {
                            this->root = successor;
                            if (this->root->getColorByVersion(version) == 'R') {
                                this->root->setColorByVersion('B', version);
                            }
                            this->rootHistory.push_back(this->root);
                        }
                        return successor;
                    }
                }
            }

            if (this->root->line->getId() == firstRoot->line->getId()) {
                this->root = root;
                if (this->root->getColorByVersion(version) == 'R') {
                    this->root = this->root->setColorByVersion('B', version);
                }
                this->rootHistory.push_back(this->root);
            }

            return root;
        }

        TreeNode* findNodeByVersion(LineSegment* line, int version) {
            TreeNode* root = this->rootHistory[version];

            while (line != root->line) {
                if (line->getPointA()->y < root->line->getPointA()->y) {
                    root = root->getLeftChildByVersion(version);
                } else if (line->getPointA()->y > root->line->getPointA()->y) {
                    root = root->getRightChildByVersion(version);
                } else {
                    if (line->getAngularCoeficient() < root->line->getAngularCoeficient()) {
                        root = root->getLeftChildByVersion(version);
                    } else if (line->getAngularCoeficient() > root->line->getAngularCoeficient()) {
                        root = root->getRightChildByVersion(version);
                    }
                }
            }

            return root; 
        }

        TreeNode* getMinNode(TreeNode* node, int version) const {
            while (node->getLeftChildByVersion(version)) {
                node = node->getLeftChildByVersion(version);
            }
            return node;
        }

        bool isLineAbovePoint(LineSegment *line, Point *point) const {
            float pointYOverLine = point->x * line->getAngularCoeficient() + line->getLinearCoeficient();
            return point->y < pointYOverLine;
        }

        LineSegment* findLineAbovePointerOnInterval(Point* point, int interval, TreeNode* root) const {
            int version = interval;
            TreeNode* currentNode = root;
            LineSegment* result = nullptr;
            LineSegment* lineSearchResult = nullptr;

            float pointY = point->y;
            float pointYOverLine = point->x * currentNode->line->getAngularCoeficient() + currentNode->line->getLinearCoeficient();
            float pointOverLineOfSearchResult = 0.0f;

            if (pointY > pointYOverLine && currentNode->getRightChildByVersion(version)) {
                lineSearchResult = this->findLineAbovePointerOnInterval(point, version, currentNode->getRightChildByVersion(version));
                return lineSearchResult;
            }

            if (pointY == pointYOverLine) {
                return currentNode->line;
            }

            if (pointY < pointYOverLine) {
                result = currentNode->line;
                if (currentNode->getLeftChildByVersion(version)) {
                    lineSearchResult = findLineAbovePointerOnInterval(point, version, currentNode->getLeftChildByVersion(version));
                    pointOverLineOfSearchResult = point->x * lineSearchResult->getAngularCoeficient() + lineSearchResult->getLinearCoeficient();
                }

                if (lineSearchResult && lineSearchResult->getId() != -1 && lineSearchResult != result && 
                    (pointOverLineOfSearchResult > pointY && pointOverLineOfSearchResult < pointYOverLine)) {
                    result = lineSearchResult;
                }

                return result;
            }

            return new LineSegment(-1);
        }
};

bool comparePointsX(const Point* pointA, const Point* pointB) {
    if (pointA->x != pointB->x) {
        return pointA->x < pointB->x;
    }
    return pointA->y < pointB->y;
}

int main() {

    int file_line_count = 0;
    int number_of_retas = 0;
    
    std::vector<LineSegment*> retas;
    std::vector<Point*> pontos;

    std::vector<std::string> input_lines;
    std::ifstream input_file("./input_1.txt");

    for (std::string line; getline(input_file, line);) {
        input_lines.push_back(line);
    }

    number_of_retas = std::stoi(input_lines[0]);

    int current_line_number = 1;
    while (current_line_number != number_of_retas + 1) {
        
        std::string current_line = input_lines[current_line_number];

        float x1 = std::stof(current_line.substr(0, current_line.find(",")));
        float y1 = std::stof(current_line.substr(current_line.find(",") + 1, current_line.find(" ") ));
        Point *pointA = new Point(x1, y1);

        current_line.erase(0, current_line.find(" ") + 1);

        float x2 = std::stof(current_line.substr(0, current_line.find(",")));
        float y2 = std::stof(current_line.substr(current_line.find(",") + 1));
        Point *pointB = new Point(x2, y2);

        LineSegment* newLine = new LineSegment(current_line_number, pointA, pointB);

        pointA->owner_line = newLine;
        pointB->owner_line = newLine;

        retas.push_back(newLine);
        pontos.push_back(pointA);
        pontos.push_back(pointB);

        current_line_number++;
    
        std::sort(pontos.begin(), pontos.end(), comparePointsX);
    }

    std::vector<LineSegment*> inputed_lines;
    RedBlackTreePersistent* auxiliaryRedBlackTree = new RedBlackTreePersistent();

    std::vector<float> ranges;

    // Inserir e remover linhas da árvore
    for (Point* point : pontos) {
        LineSegment* current_line = point->owner_line;
        if (std::find(inputed_lines.begin(), inputed_lines.end(), current_line) == inputed_lines.end()) {
            auxiliaryRedBlackTree->push(current_line, auxiliaryRedBlackTree->root);
            inputed_lines.push_back(current_line);
            ranges.push_back(current_line->getPointA()->x);
        } else {
            auxiliaryRedBlackTree->remove(current_line, auxiliaryRedBlackTree->root);
            ranges.push_back(current_line->getPointB()->x);
        }
    }
    
    int number_of_points_to_verify = std::stoi(input_lines[number_of_retas + 1]);

    std::vector<int> results;

    for (int i = 1; i <= number_of_points_to_verify; i++) {
        std::string current_line = input_lines[number_of_retas + i + 1];

        std::string str_x = current_line.substr(0, current_line.find(","));
        float point_x = std::stof(str_x);

        std::string str_y = current_line.substr(current_line.find(",") + 1);
        float point_y = std::stof(str_y);

        Point* new_point = new Point(point_x, point_y);
        int point_range = 0;
        float current_range_mark = ranges[point_range];
        
        while (new_point->x >= current_range_mark) {
            point_range++;
            current_range_mark = ranges[point_range];
        }

        results.push_back(auxiliaryRedBlackTree->findLineAbovePointerOnInterval(new_point, point_range, auxiliaryRedBlackTree->rootHistory[point_range])->getId());
    }

    // Escrever os resultados em arquivo
    std::ofstream output_file("output.txt");
    if (output_file.is_open()) {
        int current_line = 0;
        while (current_line <= input_lines.size() + results.size() + 1) {  

            if (current_line < input_lines.size()) {
                output_file << input_lines[current_line] << "\n";
            }
            if (current_line == input_lines.size() + 1) {
                output_file << "\n";
            }
            if (current_line > input_lines.size() + 1) {
                output_file << std::to_string(results[current_line - input_lines.size() - 2]) << "\n";
            }
            current_line++;
        }
        output_file.close();
    }

    return 0;
}